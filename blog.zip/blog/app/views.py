from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q  # Importando Q para filtros mais complexos
from .models import Artigo, Comentario
from .forms import ArtigoForm, ComentarioForm
from django.shortcuts import render, redirect
from .forms import PerfilForm
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import Perfil
from django.shortcuts import redirect
from django.contrib.auth import login
from django.contrib.auth.models import User


# View para a página de criação de artigo (criar.html)
@login_required
def criar_artigo(request):
    if request.method == 'POST':
        form = ArtigoForm(request.POST)
        if form.is_valid():
            # Cria o artigo com o autor associado ao usuário logado
            artigo = form.save(commit=False)
            artigo.autor = request.user  # Associa o artigo ao usuário logado
            artigo.save()  # Salva o artigo no banco de dados
            return redirect('lista_artigos')  # Redireciona após salvar
    else:
        form = ArtigoForm()  # Exibe o formulário em branco

    return render(request, 'artigos/criar.html', {'form': form})

# View para a página de lista de artigos (lista.html)
# Atualizando a view lista_artigos para não usar criado_em



from django.db.models import Q

from django.shortcuts import render
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Artigo
from django.contrib.auth.models import User

def lista_artigos(request):
    # Obtendo o filtro de busca (tema ou autor)
    q = request.GET.get('q', '')  # Filtro de busca por tema ou autor

    # Iniciando a query base para os artigos, ordenando pela data de criação (decrescente)
    artigos = Artigo.objects.all().order_by('-criado_em')  # Ordenação decrescente (mais recente primeiro)

    # Aplicando filtro de busca por tema ou autor, se o filtro for passado
    if q:
        artigos = artigos.filter(
            Q(tema__icontains=q) |  # Filtra pelo tema
            Q(autor__username__icontains=q)  # Filtra pelo nome do autor
        )

    # Paginação: criando o objeto paginator e passando para a página correta
    paginator = Paginator(artigos, 5)  # 5 artigos por página
    page = request.GET.get('page')
    page_obj = paginator.get_page(page)

    # Retornando os dados para o template
    return render(request, 'artigos/lista.html', {
        'artigos': page_obj,
        'q': q,  # Passando o filtro de busca
    })

# View para editar um artigo existente (editar.html)
def editar_artigo(request, pk):
    artigo = get_object_or_404(Artigo, pk=pk)

    if request.method == 'POST':
        form = ArtigoForm(request.POST, instance=artigo)
        if form.is_valid():
            form.save()
            return redirect('lista_artigos')  # Redireciona para a lista de artigos
    else:
        form = ArtigoForm(instance=artigo)
    
    return render(request, 'artigos/editar_artigo.html', {
        'form': form,
        'artigo': artigo
    })

# View para excluir um artigo (excluir.html)
def excluir_artigo(request, pk):
    artigo = get_object_or_404(Artigo, pk=pk)

    if request.method == 'POST':
        artigo.delete()  # Exclui o artigo
        return redirect('lista_artigos')  # Redireciona para a lista de artigos
    
    return render(request, 'artigos/excluir_artigo.html', {'artigo': artigo})

# Cadastro de usuário (cadastro.html)
def cadastro_usuario(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Cadastro realizado com sucesso! Faça login.")
            return redirect('login')  # Após cadastro, redireciona para login
        else:
            messages.error(request, "Erro ao cadastrar. Verifique os dados e tente novamente.")
    else:
        form = UserCreationForm()

    return render(request, 'registration/cadastro.html', {'form': form})

# Logout de usuário (logout.html)
def logout_view(request):
    logout(request)
    return render(request, 'registration/logout.html')

# View para adicionar um comentário em um artigo (comentar_artigo.html)
@login_required
def comentar_artigo(request, pk):
    artigo = get_object_or_404(Artigo, pk=pk)

    if request.method == 'POST':
        form = ComentarioForm(request.POST)
        if form.is_valid():
            comentario = form.save(commit=False)
            comentario.artigo = artigo
            comentario.usuario = request.user  # Associando o comentário ao usuário logado
            comentario.save()
            return redirect('comentar_artigo', pk=artigo.pk)  # Redireciona para a mesma página para ver o comentário
    else:
        form = ComentarioForm()

    # Obtém todos os comentários do artigo
    comentarios = artigo.comentarios.all()

    return render(request, 'artigos/comentar_artigo.html', {
        'artigo': artigo,
        'form': form,
        'comentarios': comentarios
    })


from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Perfil, Artigo
from .forms import PerfilForm

@login_required
def editar_perfil(request):
    try:
        # Tenta obter o perfil associado ao usuário logado
        perfil = request.user.perfil
    except Perfil.DoesNotExist:
        # Se o perfil não existir, cria um novo e associa ao usuário logado
        perfil = Perfil.objects.create(user=request.user)  # Usa 'user' em vez de 'usuario'
    
    if request.method == 'POST':
        # Usando o formulário de perfil para atualizar o perfil do usuário
        form = PerfilForm(request.POST, request.FILES, instance=perfil)
        if form.is_valid():
            form.save()
            return redirect('editar_perfil')  # Redireciona para a mesma página após salvar
    else:
        form = PerfilForm(instance=perfil)

    # Pega todos os artigos do usuário logado
    artigos = Artigo.objects.filter(autor=request.user)

    # Passa o formulário, o perfil e os artigos para o template
    return render(request, 'perfil/editar_perfil.html', {'form': form, 'perfil': perfil, 'artigos': artigos})




def entrar_como_visitante(request):
    artigos = Artigo.objects.all()  # Pegue todos os artigos
    return render(request, 'artigos/lista.html', {'artigos': artigos})