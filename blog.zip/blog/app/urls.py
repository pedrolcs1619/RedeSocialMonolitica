from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.decorators import login_required

urlpatterns = [
    # Página principal que será de login
    path('', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    
    # Outras páginas protegidas por login
    path('criar/', login_required(views.criar_artigo), name='criar_artigo'),  # Página para criar artigo
    path('artigos/', login_required(views.lista_artigos), name='lista_artigos'),  # Página para listar artigos
    path('artigo/editar/<int:pk>/', login_required(views.editar_artigo), name='editar_artigo'),  # Página para editar artigo
    path('artigo/excluir/<int:pk>/', login_required(views.excluir_artigo), name='excluir_artigo'),  # Página para excluir artigo
    path('artigo/<int:pk>/comentar/', login_required(views.comentar_artigo), name='comentar_artigo'),
    
    # Logout
    path('logout/', views.logout_view, name='logout'),
    
    # Página de cadastro de usuário
    path('cadastro/', views.cadastro_usuario, name='cadastro'),

    path('editar_perfil/', views.editar_perfil, name='editar_perfil'),

    path('entrar-como-visitante/', views.entrar_como_visitante, name='entrar_como_visitante'),
] 

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
